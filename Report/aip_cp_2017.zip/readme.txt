AIP Conference Proceedings
------------------------------------------

The following files are available in aip-cp archive:

aip-cp.cls		- This is the LaTeX2e class file for AIP Conference Proceedings template
guide.pdf	        - This is PDF of Author Guide
guide.tex	        - This is TeX of Author Guide
sample.pdf	    	- This is PDF file of sample LaTeX document
sample.tex		- This is file of sample LaTeX document
art/fig_1.eps & pdf	- Graphic files
art/fig_2.eps & pdf	- Graphic files

Happy TeXing!!!
Aptara
